# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
FirstApp::Application.config.secret_key_base = '5444e256db584c62d8305d8f9cc71507e984aae686088fc7edc7d94d041df89e987aa29464d94e14fa458b4c90f815405e4d274bf01f1e54432996476d43b164'
